<?php
// gerenciar_envios.php

// Configurações do banco de dados
$host = 'localhost';
$usuario = 'root'; // Altere conforme seu ambiente
$senha = ''; // Altere conforme seu ambiente
$banco = 'portfolio_bd';

// Conexão com o banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$banco;charset=utf8", $usuario, $senha);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['erro' => 'Erro na conexão com o banco de dados: ' . $e->getMessage()]));
}

// Definir cabeçalho para JSON
header('Content-Type: application/json');

// Função para sanitizar dados
function sanitizar($dados) {
    if (is_array($dados)) {
        return array_map('sanitizar', $dados);
    }
    return htmlspecialchars(strip_tags(trim($dados)), ENT_QUOTES, 'UTF-8');
}

// Obter ação solicitada
$acao = $_GET['acao'] ?? ($_POST['acao'] ?? '');

// Processar ações
switch ($acao) {
    case 'listarPessoas':
        listarPessoas();
        break;
        
    case 'ver':
        verMensagem();
        break;
        
    case 'editar':
        editarMensagem();
        break;
        
    case 'excluir':
        excluirMensagem();
        break;
        
    default:
        echo json_encode(['erro' => 'Ação não especificada']);
        break;
}

// ============================================
// FUNÇÕES DO SISTEMA
// ============================================

/**
 * Lista todas as pessoas com suas mensagens (agrupadas)
 */
function listarPessoas() {
    global $pdo;
    
    // Obter filtros
    $filtro_status = $_GET['status'] ?? 'todos';
    $filtro_ordem = $_GET['ordem'] ?? 'recente';
    $busca = $_GET['busca'] ?? '';
    
    // Construir consulta para agrupar por pessoa
    $sql = "
        SELECT 
            email,
            nome,
            telefone,
            COUNT(*) as total_mensagens,
            MAX(data_envio) as ultima_mensagem
        FROM contatos
    ";
    
    // Adicionar WHERE se houver filtros
    $where = [];
    $params = [];
    
    if ($filtro_status !== 'todos') {
        $where[] = "status = ?";
        $params[] = $filtro_status;
    }
    
    if (!empty($busca)) {
        $where[] = "(nome LIKE ? OR email LIKE ? OR assunto LIKE ? OR mensagem LIKE ?)";
        $busca_param = "%$busca%";
        $params[] = $busca_param;
        $params[] = $busca_param;
        $params[] = $busca_param;
        $params[] = $busca_param;
    }
    
    // Adicionar WHERE à consulta
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    
    // Agrupar por pessoa (email)
    $sql .= " GROUP BY email, nome, telefone";
    
    // Adicionar ordenação
    switch ($filtro_ordem) {
        case 'antigo':
            $sql .= " ORDER BY ultima_mensagem ASC";
            break;
        case 'nome':
            $sql .= " ORDER BY nome ASC";
            break;
        case 'recente':
        default:
            $sql .= " ORDER BY ultima_mensagem DESC";
            break;
    }
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $pessoas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Para cada pessoa, buscar suas mensagens
        foreach ($pessoas as &$pessoa) {
            $sql_mensagens = "
                SELECT 
                    id,
                    nome,
                    email,
                    telefone,
                    assunto,
                    mensagem,
                    resposta,
                    status,
                    prioridade,
                    tags,
                    lido,
                    DATE_FORMAT(data_envio, '%Y-%m-%d %H:%i:%s') as data_envio,
                    DATE_FORMAT(data_resposta, '%Y-%m-%d %H:%i:%s') as data_resposta
                FROM contatos 
                WHERE email = ?
            ";
            
            // Adicionar filtro de status se aplicável
            $params_mensagens = [$pessoa['email']];
            
            $sql_mensagens .= " ORDER BY data_envio DESC";
            
            $stmt_mensagens = $pdo->prepare($sql_mensagens);
            $stmt_mensagens->execute($params_mensagens);
            $pessoa['mensagens'] = $stmt_mensagens->fetchAll(PDO::FETCH_ASSOC);
            
            // Adicionar um ID único para a pessoa (baseado no email)
            $pessoa['id'] = md5($pessoa['email']);
        }
        
        // Calcular estatísticas
        $estatisticas = calcularEstatisticas($pdo);
        
        echo json_encode([
            'pessoas' => $pessoas,
            'estatisticas' => $estatisticas
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['erro' => 'Erro ao listar pessoas: ' . $e->getMessage()]);
    }
}

/**
 * Calcula estatísticas do sistema
 */
function calcularEstatisticas($pdo) {
    $estatisticas = [];
    
    try {
        // Total de mensagens
        $sql = "SELECT COUNT(*) as total FROM contatos";
        $stmt = $pdo->query($sql);
        $estatisticas['total_mensagens'] = $stmt->fetchColumn();
        
        // Total de pessoas distintas
        $sql = "SELECT COUNT(DISTINCT email) as total FROM contatos";
        $stmt = $pdo->query($sql);
        $estatisticas['total_pessoas'] = $stmt->fetchColumn();
        
        // Mensagens novas
        $sql = "SELECT COUNT(*) as total FROM contatos WHERE status = 'novo'";
        $stmt = $pdo->query($sql);
        $estatisticas['novos'] = $stmt->fetchColumn();
        
        // Mensagens respondidas
        $sql = "SELECT COUNT(*) as total FROM contatos WHERE status = 'respondido'";
        $stmt = $pdo->query($sql);
        $estatisticas['respondidos'] = $stmt->fetchColumn();
        
        // Mensagens em andamento
        $sql = "SELECT COUNT(*) as total FROM contatos WHERE status = 'em_andamento'";
        $stmt = $pdo->query($sql);
        $estatisticas['em_andamento'] = $stmt->fetchColumn();
        
        // Mensagens concluídas
        $sql = "SELECT COUNT(*) as total FROM contatos WHERE status = 'concluido'";
        $stmt = $pdo->query($sql);
        $estatisticas['concluidos'] = $stmt->fetchColumn();
        
    } catch (PDOException $e) {
        $estatisticas = [
            'total_mensagens' => 0,
            'total_pessoas' => 0,
            'novos' => 0,
            'respondidos' => 0,
            'em_andamento' => 0,
            'concluidos' => 0
        ];
    }
    
    return $estatisticas;
}

/**
 * Visualiza detalhes de uma mensagem específica
 */
function verMensagem() {
    global $pdo;
    
    $id = $_GET['id'] ?? 0;
    
    if (!$id) {
        echo json_encode(['erro' => 'ID da mensagem não especificado']);
        return;
    }
    
    try {
        $sql = "
            SELECT 
                id,
                nome,
                email,
                telefone,
                assunto,
                mensagem,
                resposta,
                status,
                prioridade,
                tags,
                lido,
                DATE_FORMAT(data_envio, '%Y-%m-%d %H:%i:%s') as data_envio,
                DATE_FORMAT(data_resposta, '%Y-%m-%d %H:%i:%s') as data_resposta
            FROM contatos
            WHERE id = ?
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        $mensagem = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($mensagem) {
            // Marcar como lido se ainda não estiver
            if (!$mensagem['lido']) {
                $sql_update = "UPDATE contatos SET lido = 1 WHERE id = ?";
                $stmt_update = $pdo->prepare($sql_update);
                $stmt_update->execute([$id]);
            }
            
            echo json_encode($mensagem);
        } else {
            echo json_encode(['erro' => 'Mensagem não encontrada']);
        }
        
    } catch (PDOException $e) {
        echo json_encode(['erro' => 'Erro ao buscar mensagem: ' . $e->getMessage()]);
    }
}

/**
 * Edita uma mensagem existente
 */
function editarMensagem() {
    global $pdo;
    
    // Sanitizar dados
    $dados = sanitizar($_POST);
    
    $id = $dados['id'] ?? 0;
    $nome = $dados['nome'] ?? '';
    $email = $dados['email'] ?? '';
    $telefone = $dados['telefone'] ?? '';
    $assunto = $dados['assunto'] ?? '';
    $mensagem = $dados['mensagem'] ?? '';
    $status = $dados['status'] ?? 'novo';
    $resposta = $dados['resposta'] ?? '';
    $prioridade = $dados['prioridade'] ?? 'baixa';
    $tags = $dados['tags'] ?? '';
    
    if (!$id || !$nome || !$email || !$assunto || !$mensagem) {
        echo json_encode(['erro' => 'Dados incompletos']);
        return;
    }
    
    try {
        // Verificar se o email foi alterado
        $sql_verificar_email = "SELECT email FROM contatos WHERE id = ?";
        $stmt_verificar = $pdo->prepare($sql_verificar_email);
        $stmt_verificar->execute([$id]);
        $mensagem_atual = $stmt_verificar->fetch(PDO::FETCH_ASSOC);
        
        if (!$mensagem_atual) {
            echo json_encode(['erro' => 'Mensagem não encontrada']);
            return;
        }
        
        $email_antigo = $mensagem_atual['email'];
        
        // Preparar dados para atualização
        $data_atualizacao = date('Y-m-d H:i:s');
        $data_resposta = null;
        
        // Se o status for respondido e houver resposta, atualizar data_resposta
        if (($status === 'respondido' || $status === 'concluido') && !empty($resposta)) {
            $data_resposta = $data_atualizacao;
        }
        
        // Atualizar a mensagem
        $sql_atualizar = "
            UPDATE contatos 
            SET nome = ?, 
                email = ?, 
                telefone = ?, 
                assunto = ?, 
                mensagem = ?, 
                status = ?, 
                resposta = ?, 
                prioridade = ?, 
                tags = ?,
                data_resposta = ?,
                lido = 1
            WHERE id = ?
        ";
        
        $stmt_atualizar = $pdo->prepare($sql_atualizar);
        $stmt_atualizar->execute([
            $nome, 
            $email, 
            $telefone, 
            $assunto, 
            $mensagem, 
            $status, 
            $resposta, 
            $prioridade, 
            $tags,
            $data_resposta,
            $id
        ]);
        
        // Se o email foi alterado, atualizar todas as mensagens desse email antigo
        if ($email !== $email_antigo) {
            $sql_atualizar_todas = "UPDATE contatos SET email = ? WHERE email = ? AND id != ?";
            $stmt_atualizar_todas = $pdo->prepare($sql_atualizar_todas);
            $stmt_atualizar_todas->execute([$email, $email_antigo, $id]);
        }
        
        echo json_encode(['sucesso' => 'Mensagem atualizada com sucesso']);
        
    } catch (PDOException $e) {
        echo json_encode(['erro' => 'Erro ao atualizar mensagem: ' . $e->getMessage()]);
    }
}

/**
 * Exclui uma mensagem
 */
function excluirMensagem() {
    global $pdo;
    
    $id = $_GET['id'] ?? 0;
    
    if (!$id) {
        echo json_encode(['erro' => 'ID da mensagem não especificado']);
        return;
    }
    
    try {
        // Primeiro, buscar o email da mensagem para verificar se há outras mensagens
        $sql_info = "
            SELECT email, 
                   (SELECT COUNT(*) FROM contatos WHERE email = c.email) as total_mensagens
            FROM contatos c 
            WHERE id = ?
        ";
        
        $stmt_info = $pdo->prepare($sql_info);
        $stmt_info->execute([$id]);
        $info = $stmt_info->fetch(PDO::FETCH_ASSOC);
        
        if (!$info) {
            echo json_encode(['erro' => 'Mensagem não encontrada']);
            return;
        }
        
        // Excluir a mensagem
        $sql_excluir = "DELETE FROM contatos WHERE id = ?";
        $stmt_excluir = $pdo->prepare($sql_excluir);
        $stmt_excluir->execute([$id]);
        
        echo json_encode(['sucesso' => 'Mensagem excluída com sucesso']);
        
    } catch (PDOException $e) {
        echo json_encode(['erro' => 'Erro ao excluir mensagem: ' . $e->getMessage()]);
    }
}