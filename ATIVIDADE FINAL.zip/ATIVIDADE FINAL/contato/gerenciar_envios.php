<?php
// admin.php - Painel de administração para portfolio_bd
session_start();

// Configurações
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'portfolio_bd'; // NOME DO BANCO ATUALIZADO

// Senha do painel (ALTERE ISSO!)
$senha_admin = 'portfolio123';

// Verificar login
if (!isset($_SESSION['logado'])) {
    if (isset($_POST['senha'])) {
        if ($_POST['senha'] === $senha_admin) {
            $_SESSION['logado'] = true;
            $_SESSION['login_time'] = time();
        } else {
            $erro_login = "Senha incorreta!";
        }
    }
    
    if (!isset($_SESSION['logado'])) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Login - Portfolio BD Admin</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
                body { background: linear-gradient(135deg, #9900ff 0%, #fbff00 100%); height: 100vh; display: flex; justify-content: center; align-items: center; }
                .login-box { background: white; padding: 50px; border-radius: 20px; box-shadow: 0 20px 50px rgba(0,0,0,0.3); text-align: center; width: 90%; max-width: 400px; }
                .logo { color: #9900ff; font-size: 3rem; margin-bottom: 20px; }
                h2 { color: #333; margin-bottom: 10px; }
                p { color: #666; margin-bottom: 30px; }
                input { width: 100%; padding: 15px; margin: 10px 0; border: 2px solid #ddd; border-radius: 10px; font-size: 1rem; }
                input:focus { outline: none; border-color: #9900ff; }
                button { width: 100%; padding: 15px; background: linear-gradient(45deg, #9900ff, #fbff00); border: none; border-radius: 10px; color: #000; font-weight: bold; font-size: 1.1rem; cursor: pointer; margin-top: 10px; }
                button:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(153,0,255,0.3); }
                .erro { color: #dc3545; margin-top: 10px; }
                .info { background: #f8f9fa; padding: 15px; border-radius: 10px; margin-top: 20px; font-size: 0.9rem; }
            </style>
        </head>
        <body>
            <div class="login-box">
                <div class="logo">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h2>Painel Admin - Portfolio BD</h2>
                <p>Acesso restrito aos contatos recebidos</p>
                
                <?php if (isset($erro_login)): ?>
                    <div class="erro"><?php echo $erro_login; ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="password" name="senha" placeholder="Digite a senha de acesso" required>
                    <button type="submit">
                        <i class="fas fa-sign-in-alt"></i> Entrar no Painel
                    </button>
                </form>
                
                <div class="info">
                    <i class="fas fa-info-circle"></i> Banco de dados: <strong>portfolio_bd</strong>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// Logout automático após 30 minutos
if (time() - $_SESSION['login_time'] > 1800) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Conectar ao banco
$conexao = new mysqli($host, $usuario, $senha, $banco);
if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}
$conexao->set_charset("utf8mb4");

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? 0;

switch ($acao) {
    case 'marcar_lido':
        $conexao->query("UPDATE contatos SET lido = TRUE WHERE id = $id");
        break;
    case 'marcar_nao_lido':
        $conexao->query("UPDATE contatos SET lido = FALSE WHERE id = $id");
        break;
    case 'excluir':
        $conexao->query("DELETE FROM contatos WHERE id = $id");
        break;
    case 'exportar':
        exportarCSV($conexao);
        break;
    case 'logout':
        session_destroy();
        header('Location: admin.php');
        exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - Portfolio BD</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #f5f5f5; color: #333; }
        .header { background: linear-gradient(45deg, #9900ff, #fbff00); color: #000; padding: 25px 40px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .header h1 { font-size: 1.8rem; display: flex; align-items: center; gap: 15px; }
        .header-info { display: flex; gap: 20px; }
        .header-info div { background: rgba(0,0,0,0.1); padding: 10px 20px; border-radius: 10px; font-weight: bold; }
        .container { max-width: 1400px; margin: 0 auto; padding: 30px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .stat-card { background: white; padding: 25px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center; border-top: 5px solid; }
        .stat-card.total { border-color: #9900ff; }
        .stat-card.hoje { border-color: #28a745; }
        .stat-card.nao-lidos { border-color: #dc3545; }
        .stat-card.semana { border-color: #17a2b8; }
        .stat-number { font-size: 2.5rem; font-weight: bold; margin: 10px 0; }
        .stat-label { color: #666; font-size: 0.9rem; }
        .filtros { background: white; padding: 20px; border-radius: 15px; margin: 20px 0; display: flex; gap: 15px; flex-wrap: wrap; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-weight: 600; text-decoration: none; transition: all 0.3s; }
        .btn-primary { background: #9900ff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-warning { background: #ffc107; color: #000; }
        .btn-info { background: #17a2b8; color: white; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        table { width: 100%; background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #9900ff; color: white; font-weight: 600; }
        tr:hover { background: #f9f9f9; }
        .status-lido { color: #28a745; font-weight: bold; }
        .status-nao-lido { color: #dc3545; font-weight: bold; }
        .acoes { display: flex; gap: 5px; flex-wrap: wrap; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: white; padding: 30px; border-radius: 15px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .modal-close { cursor: pointer; font-size: 1.5rem; }
        .pagination { display: flex; justify-content: center; gap: 10px; margin: 30px 0; }
        .pagination a { padding: 10px 15px; background: white; border-radius: 8px; text-decoration: none; color: #333; }
        .pagination a.active { background: #9900ff; color: white; }
        @media (max-width: 768px) {
            .header { flex-direction: column; gap: 15px; text-align: center; }
            .header-info { flex-wrap: wrap; justify-content: center; }
            table { font-size: 0.9rem; }
            th, td { padding: 10px; }
        }
    </style>
</head>
<body>
    <!-- Cabeçalho -->
    <div class="header">
        <h1>
            <i class="fas fa-chart-line"></i>
            Painel Admin - Portfolio BD
        </h1>
        <div class="header-info">
            <div>
                <i class="fas fa-database"></i>
                Banco: portfolio_bd
            </div>
            <div>
                <i class="fas fa-user"></i>
                Admin
            </div>
            <div>
                <i class="fas fa-clock"></i>
                <?php echo date('d/m/Y H:i'); ?>
            </div>
        </div>
    </div>
    
    <div class="container">
        <?php
        // Estatísticas
        $total = $conexao->query("SELECT COUNT(*) as total FROM contatos")->fetch_assoc()['total'];
        $hoje = $conexao->query("SELECT COUNT(*) as hoje FROM contatos WHERE DATE(data_envio) = CURDATE()")->fetch_assoc()['hoje'];
        $nao_lidos = $conexao->query("SELECT COUNT(*) as nao_lidos FROM contatos WHERE lido = FALSE")->fetch_assoc()['nao_lidos'];
        $semana = $conexao->query("SELECT COUNT(*) as semana FROM contatos WHERE data_envio >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['semana'];
        ?>
        
        <!-- Estatísticas -->
        <div class="stats-grid">
            <div class="stat-card total">
                <div class="stat-label">Total de Contatos</div>
                <div class="stat-number"><?php echo $total; ?></div>
            </div>
            <div class="stat-card hoje">
                <div class="stat-label">Contatos Hoje</div>
                <div class="stat-number"><?php echo $hoje; ?></div>
            </div>
            <div class="stat-card nao-lidos">
                <div class="stat-label">Não Lidos</div>
                <div class="stat-number"><?php echo $nao_lidos; ?></div>
            </div>
            <div class="stat-card semana">
                <div class="stat-label">Últimos 7 Dias</div>
                <div class="stat-number"><?php echo $semana; ?></div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="filtros">
            <a href="?filtro=todos" class="btn btn-primary">
                <i class="fas fa-list"></i> Todos
            </a>
            <a href="?filtro=nao_lidos" class="btn btn-danger">
                <i class="fas fa-envelope"></i> Não Lidos
            </a>
            <a href="?filtro=hoje" class="btn btn-success">
                <i class="fas fa-calendar-day"></i> Hoje
            </a>
            <a href="?acao=exportar" class="btn btn-info">
                <i class="fas fa-file-export"></i> Exportar CSV
            </a>
            <a href="contato.html" target="_blank" class="btn">
                <i class="fas fa-plus"></i> Novo Teste
            </a>
            <a href="?acao=logout" class="btn btn-warning" style="margin-left: auto;">
                <i class="fas fa-sign-out-alt"></i> Sair
            </a>
        </div>
        
        <!-- Tabela de Contatos -->
        <?php
        // Determinar filtro
        $filtro = $_GET['filtro'] ?? 'todos';
        $where = '';
        
        switch ($filtro) {
            case 'nao_lidos': $where = "WHERE lido = FALSE"; break;
            case 'hoje': $where = "WHERE DATE(data_envio) = CURDATE()"; break;
            case 'semana': $where = "WHERE data_envio >= DATE_SUB(NOW(), INTERVAL 7 DAY)"; break;
        }
        
        // Paginação
        $registros_por_pagina = 15;
        $pagina = $_GET['pagina'] ?? 1;
        $offset = ($pagina - 1) * $registros_por_pagina;
        
        // Total de páginas
        $total_result = $conexao->query("SELECT COUNT(*) as total FROM contatos $where");
        $total_registros = $total_result->fetch_assoc()['total'];
        $total_paginas = ceil($total_registros / $registros_por_pagina);
        
        // Buscar contatos
        $query = "SELECT * FROM contatos $where ORDER BY data_envio DESC LIMIT $offset, $registros_por_pagina";
        $result = $conexao->query($query);
        ?>
        
        <h3>
            <i class="fas fa-table"></i>
            Lista de Contatos 
            <small>(<?php echo $total_registros; ?> registros)</small>
        </h3>
        
        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data/Hora</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Assunto</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><strong>#<?php echo $row['id']; ?></strong></td>
                            <td><?php echo date('d/m/Y H:i', strtotime($row['data_envio'])); ?></td>
                            <td><strong><?php echo htmlspecialchars($row['nome']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefone']); ?></td>
                            <td><?php echo htmlspecialchars($row['assunto']); ?></td>
                            <td>
                                <?php if ($row['lido']): ?>
                                    <span class="status-lido"><i class="fas fa-check-circle"></i> Lido</span>
                                <?php else: ?>
                                    <span class="status-nao-lido"><i class="fas fa-envelope"></i> Novo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="acoes">
                                    <button class="btn btn-primary btn-sm" onclick="verMensagem(<?php echo $row['id']; ?>, '<?php echo addslashes($row['nome']); ?>')">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    
                                    <?php if ($row['lido']): ?>
                                        <a href="?acao=marcar_nao_lido&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-envelope"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="?acao=marcar_lido&id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">
                                            <i class="fas fa-check"></i>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="?acao=excluir&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Excluir este contato?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            
            <!-- Paginação -->
            <?php if ($total_paginas > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                        <a href="?pagina=<?php echo $i; ?>&filtro=<?php echo $filtro; ?>" class="<?php echo $i == $pagina ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div style="background: white; padding: 40px; text-align: center; border-radius: 15px; margin: 20px 0;">
                <i class="fas fa-inbox" style="font-size: 3rem; color: #999; margin-bottom: 20px;"></i>
                <h3 style="color: #666;">Nenhum contato encontrado</h3>
                <p style="color: #888;">Use o formulário de contato para enviar uma mensagem.</p>
                <a href="contato.html" target="_blank" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-plus"></i> Testar Formulário
                </a>
            </div>
        <?php endif; ?>
        
        <!-- Modal para ver mensagem -->
        <div id="modalMensagem" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="modalTitulo"></h3>
                    <span class="modal-close" onclick="fecharModal()">&times;</span>
                </div>
                <div id="modalConteudo"></div>
            </div>
        </div>
    </div>
    
    <script>
        // Modal para ver mensagens
        function verMensagem(id, nome) {
            fetch(`get_mensagem.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('modalTitulo').innerHTML = 
                        `<i class="fas fa-user"></i> Mensagem de ${nome}`;
                    
                    let conteudo = `
                        <div style="margin-bottom: 20px;">
                            <p><strong>Data:</strong> ${data.data_envio}</p>
                            <p><strong>E-mail:</strong> ${data.email}</p>
                            <p><strong>Telefone:</strong> ${data.telefone || 'Não informado'}</p>
                            <p><strong>Assunto:</strong> ${data.assunto}</p>
                        </div>
                        <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
                            <h4><i class="fas fa-comment"></i> Mensagem:</h4>
                            <p style="white-space: pre-wrap; line-height: 1.6;">${data.mensagem}</p>
                        </div>
                    `;
                    
                    document.getElementById('modalConteudo').innerHTML = conteudo;
                    document.getElementById('modalMensagem').style.display = 'flex';
                });
        }
        
        function fecharModal() {
            document.getElementById('modalMensagem').style.display = 'none';
        }
        
        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            const modal = document.getElementById('modalMensagem');
            if (event.target === modal) {
                fecharModal();
            }
        }
        
        // Auto-atualizar a cada 2 minutos
        setTimeout(() => {
            location.reload();
        }, 120000);
    </script>
</body>
</html>
<?php
$conexao->close();

// Função para exportar CSV
function exportarCSV($conexao) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=contatos_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Data', 'Nome', 'E-mail', 'Telefone', 'Assunto', 'Mensagem', 'Lido'], ';');
    
    $result = $conexao->query("SELECT * FROM contatos ORDER BY data_envio DESC");
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['id'],
            $row['data_envio'],
            $row['nome'],
            $row['email'],
            $row['telefone'],
            $row['assunto'],
            $row['mensagem'],
            $row['lido'] ? 'Sim' : 'Não'
        ], ';');
    }
    
    fclose($output);
    exit;
}
?>