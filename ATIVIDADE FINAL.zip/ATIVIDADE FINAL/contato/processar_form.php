<?php
// processar_form.php

// Configurações do banco de dados
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'portfolio_bd';

// Conexão com o banco
try {
    $pdo = new PDO("mysql:host=$host;dbname=$banco;charset=utf8", $usuario, $senha);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

// Receber dados do formulário
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$assunto = $_POST['assunto'] ?? '';
$mensagem = $_POST['mensagem'] ?? '';

// Validar dados
if (empty($nome) || empty($email) || empty($assunto) || empty($mensagem)) {
    die("Por favor, preencha todos os campos obrigatórios.");
}

// Validar email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Por favor, insira um e-mail válido.");
}

// Sanitizar
$nome = htmlspecialchars(strip_tags($nome));
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$telefone = htmlspecialchars(strip_tags($telefone));
$assunto = htmlspecialchars(strip_tags($assunto));
$mensagem = htmlspecialchars(strip_tags($mensagem));

try {
    // Preparar SQL para inserir
    $sql = "
        INSERT INTO contatos (nome, email, telefone, assunto, mensagem, status, prioridade) 
        VALUES (?, ?, ?, ?, ?, 'novo', 'baixa')
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nome, $email, $telefone, $assunto, $mensagem]);
    
    // Redirecionar com sucesso
    header('Location: contato.html?status=success');
    exit();
    
} catch (PDOException $e) {
    die("Erro ao salvar mensagem: " . $e->getMessage());
}