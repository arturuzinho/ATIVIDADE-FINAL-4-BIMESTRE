<?php
// ============================================
// salvar.php - VERSÃO LIMPA (APENAS success/error)
// ============================================

// Configurar para retornar texto simples
header('Content-Type: text/plain; charset=utf-8');

// ============================================
// 1. VERIFICAR SE É UMA REQUISIÇÃO POST
// ============================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "success"; // Para teste direto no navegador
    exit;
}

// ============================================
// 2. VALIDAR DADOS DO FORMULÁRIO (SILENCIOSO)
// ============================================
$campos_obrigatorios = ['nome', 'email', 'assunto', 'mensagem'];
$dados = [];

foreach ($campos_obrigatorios as $campo) {
    if (empty($_POST[$campo])) {
        echo "error";
        exit;
    }
    $dados[$campo] = trim($_POST[$campo]);
}

// Validações básicas (sem mensagem detalhada)
if (strlen($dados['nome']) < 3 || !filter_var($dados['email'], FILTER_VALIDATE_EMAIL) || strlen($dados['mensagem']) < 10) {
    echo "error";
    exit;
}

// Campo opcional
$dados['telefone'] = !empty($_POST['telefone']) ? trim($_POST['telefone']) : '';

// ============================================
// 3. CONEXÃO E SALVAMENTO (SILENCIOSO)
// ============================================
try {
    // Tentar conexão
    $conexao = @new mysqli('localhost', 'root', '', 'portfolio_bd');
    
    // Se falhar, tentar criar banco/tabela
    if ($conexao->connect_error) {
        $conexao = @new mysqli('localhost', 'root', '');
        if (!$conexao->connect_error) {
            $conexao->query("CREATE DATABASE IF NOT EXISTS portfolio_bd");
            $conexao->select_db('portfolio_bd');
            $conexao->query("CREATE TABLE IF NOT EXISTS contatos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                telefone VARCHAR(20),
                assunto VARCHAR(50) NOT NULL,
                mensagem TEXT NOT NULL,
                data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                lido BOOLEAN DEFAULT FALSE
            )");
        }
    }
    
    // Configurar charset
    $conexao->set_charset("utf8mb4");
    
    // Preparar e executar inserção
    $stmt = $conexao->prepare("INSERT INTO contatos (nome, email, telefone, assunto, mensagem) VALUES (?, ?, ?, ?, ?)");
    
    if ($stmt) {
        $stmt->bind_param("sssss", 
            $dados['nome'],
            $dados['email'],
            $dados['telefone'],
            $dados['assunto'],
            $dados['mensagem']
        );
        
        if ($stmt->execute()) {
            echo "success"; // APENAS ISTO!
        } else {
            echo "error";
        }
        
        $stmt->close();
    } else {
        echo "error";
    }
    
    $conexao->close();
    
} catch (Exception $e) {
    echo "error";
}

// ============================================
// FIM - Nada mais é impresso
// ============================================
?>