<?php
// processar_contato.php - Versão simplificada para debug

// Configurações do banco de dados - AJUSTE AQUI!
$host = 'localhost';
$usuario = 'root';      // Altere se seu MySQL usa outro usuário
$senha = '';            // Altere se seu MySQL tem senha
$banco = 'portfolio_db';

// Receber dados do formulário
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$assunto = $_POST['assunto'] ?? '';
$mensagem = $_POST['mensagem'] ?? '';

// Validar dados obrigatórios
if (empty($nome) || empty($email) || empty($assunto) || empty($mensagem)) {
    echo 'error: Campos obrigatórios não preenchidos';
    exit();
}

// Validar e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo 'error: E-mail inválido';
    exit();
}

// TENTATIVA DE CONEXÃO COM MENSAGENS DE DEBUG
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Primeiro, testar sem o banco
$conexao = @new mysqli($host, $usuario, $senha);

if ($conexao->connect_error) {
    // Erro na conexão básica
    echo 'error: Não foi possível conectar ao MySQL. Verifique:';
    echo ' 1. Se o MySQL está rodando (XAMPP/WAMP)';
    echo ' 2. Usuário: ' . $usuario;
    echo ' 3. Senha: ' . ($senha ? '***' : '(vazia)');
    exit();
}

// Agora testar o banco específico
if (!$conexao->select_db($banco)) {
    // Banco não existe, tentar criar
    $sql_create_db = "CREATE DATABASE IF NOT EXISTS $banco 
                      CHARACTER SET utf8mb4 
                      COLLATE utf8mb4_unicode_ci";
    
    if ($conexao->query($sql_create_db)) {
        $conexao->select_db($banco);
        echo 'info: Banco de dados criado automaticamente.<br>';
    } else {
        echo 'error: Banco não existe e não pôde ser criado.';
        $conexao->close();
        exit();
    }
}

// Agora conectado ao banco, criar tabela se não existir
$sql_create_table = "CREATE TABLE IF NOT EXISTS contatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20),
    assunto VARCHAR(100) NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if (!$conexao->query($sql_create_table)) {
    echo 'error: Não foi possível criar a tabela: ' . $conexao->error;
    $conexao->close();
    exit();
}

// Inserir os dados
$sql_insert = "INSERT INTO contatos (nome, email, telefone, assunto, mensagem) 
               VALUES (?, ?, ?, ?, ?)";
               
$stmt = $conexao->prepare($sql_insert);

if (!$stmt) {
    echo 'error: Erro ao preparar a query: ' . $conexao->error;
    $conexao->close();
    exit();
}

// Vincular parâmetros
$stmt->bind_param("sssss", $nome, $email, $telefone, $assunto, $mensagem);

// Executar
if ($stmt->execute()) {
    // SUCESSO!
    echo 'success';
} else {
    echo 'error: Erro ao salvar: ' . $stmt->error;
}

// Fechar conexões
$stmt->close();
$conexao->close();
?>