<?php
header('Content-Type: text/html; charset=utf-8');

// Configurações
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'portfolio_bd'; // NOME DO BANCO ATUALIZADO
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste de Conexão - Portfolio BD</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        }
        
        body { 
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); 
            min-height: 100vh; 
            padding: 20px; 
        }
        
        .container { 
            max-width: 1200px; 
            margin: 0 auto; 
            background: white; 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 15px 40px rgba(153, 0, 255, 0.15); 
        }
        
        .header { 
            text-align: center; 
            margin-bottom: 40px; 
            padding-bottom: 20px; 
            border-bottom: 3px solid #9900ff; 
        }
        
        .header h1 { 
            color: #9900ff; 
            font-size: 2.5rem; 
            margin-bottom: 10px; 
        }
        
        .header h2 { 
            color: #666; 
            font-weight: normal; 
        }
        
        .card { 
            background: #f8f9fa; 
            border-radius: 15px; 
            padding: 25px; 
            margin-bottom: 25px; 
            border-left: 5px solid; 
        }
        
        .card h3 { 
            display: flex; 
            align-items: center; 
            gap: 10px; 
            margin-bottom: 15px; 
            font-size: 1.3rem; 
        }
        
        .card-conexao { border-left-color: #007bff; }
        .card-banco { border-left-color: #28a745; }
        .card-tabela { border-left-color: #ffc107; }
        .card-dados { border-left-color: #17a2b8; }
        .card-arquivos { border-left-color: #6f42c1; }
        .card-acoes { border-left-color: #9900ff; }
        
        .status-box { 
            padding: 15px; 
            border-radius: 10px; 
            margin: 10px 0; 
            font-weight: bold; 
        }
        
        .sucesso { 
            background: #d4edda; 
            color: #155724; 
            border: 2px solid #155724; 
        }
        
        .erro { 
            background: #f8d7da; 
            color: #721c24; 
            border: 2px solid #721c24; 
        }
        
        .info { 
            background: #d1ecf1; 
            color: #0c5460; 
            border: 2px solid #0c5460; 
        }
        
        .alerta { 
            background: #fff3cd; 
            color: #856404; 
            border: 2px solid #ffc107; 
        }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 20px 0; 
        }
        
        th, td { 
            padding: 12px 15px; 
            text-align: left; 
            border-bottom: 1px solid #ddd; 
        }
        
        th { 
            background: #9900ff; 
            color: white; 
            font-weight: 600; 
        }
        
        tr:hover { 
            background: #f5f5f5; 
        }
        
        .btn { 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            padding: 12px 25px; 
            background: #9900ff; 
            color: white; 
            text-decoration: none; 
            border-radius: 10px; 
            margin: 10px 5px; 
            font-weight: 600; 
            transition: all 0.3s ease; 
            border: none; 
            cursor: pointer; 
        }
        
        .btn:hover { 
            background: #8800ee; 
            transform: translateY(-2px); 
            box-shadow: 0 5px 15px rgba(153, 0, 255, 0.3); 
        }
        
        .btn-verde { background: #28a745; }
        .btn-verde:hover { background: #218838; }
        
        .btn-vermelho { background: #dc3545; }
        .btn-vermelho:hover { background: #c82333; }
        
        .btn-azul { background: #17a2b8; }
        .btn-azul:hover { background: #138496; }
        
        .code { 
            background: #2d3748; 
            color: #e2e8f0; 
            padding: 20px; 
            border-radius: 10px; 
            font-family: 'Courier New', monospace; 
            margin: 15px 0; 
            overflow-x: auto; 
        }
        
        .destaque { 
            background: linear-gradient(45deg, #9900ff20, #fbff0020); 
            padding: 20px; 
            border-radius: 10px; 
            margin: 20px 0; 
            border: 2px solid #9900ff; 
        }
        
        .grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 20px; 
            margin: 25px 0; 
        }
        
        .stat-box { 
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            text-align: center; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.1); 
            border: 2px solid #9900ff; 
        }
        
        .stat-number { 
            font-size: 2.5rem; 
            font-weight: bold; 
            color: #9900ff; 
            margin: 10px 0; 
        }
        
        .stat-label { 
            color: #666; 
            font-size: 0.9rem; 
        }
        
        @media (max-width: 768px) {
            .container { padding: 20px; }
            table { font-size: 0.9rem; }
            th, td { padding: 8px 10px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Cabeçalho -->
        <div class="header">
            <h1><i class="fas fa-database"></i> Teste de Conexão - Portfolio BD</h1>
            <h2>Sistema de Gerenciamento de Banco de Dados</h2>
            <p>Banco de dados: <strong>portfolio_bd</strong> | Servidor: <strong><?php echo $host; ?></strong></p>
        </div>
        
        <?php
        // ============================================
        // TESTE 1: CONEXÃO COM MYSQL
        // ============================================
        echo '<div class="card card-conexao">';
        echo '<h3><i class="fas fa-plug"></i> 1. Testando Conexão com MySQL...</h3>';
        
        $conexao = @new mysqli($host, $usuario, $senha);
        
        if ($conexao->connect_error) {
            echo '<div class="status-box erro">';
            echo '<i class="fas fa-times-circle"></i> ❌ Falha na conexão com MySQL';
            echo '<p>Erro: ' . $conexao->connect_error . '</p>';
            echo '</div>';
            
            echo '<div class="alerta status-box">';
            echo '<h4><i class="fas fa-lightbulb"></i> Solução:</h4>';
            echo '<ol>';
            echo '<li>Abra o XAMPP Control Panel</li>';
            echo '<li>Clique em "Start" no módulo MySQL</li>';
            echo '<li>Verifique se a porta 3306 está disponível</li>';
            echo '</ol>';
            echo '</div>';
            
        } else {
            echo '<div class="status-box sucesso">';
            echo '<i class="fas fa-check-circle"></i> ✅ Conectado ao servidor MySQL com sucesso!';
            echo '<p>Versão do MySQL: ' . $conexao->server_version . '</p>';
            echo '</div>';
            
            // ============================================
            // TESTE 2: BANCO DE DADOS portfolio_bd
            // ============================================
            echo '<div class="card card-banco">';
            echo '<h3><i class="fas fa-database"></i> 2. Verificando banco de dados "portfolio_bd"...</h3>';
            
            if ($conexao->select_db($banco)) {
                echo '<div class="status-box sucesso">';
                echo '<i class="fas fa-check-circle"></i> ✅ Banco de dados "' . $banco . '" encontrado!';
                echo '</div>';
                
                // ============================================
                // TESTE 3: TABELA contatos
                // ============================================
                echo '<div class="card card-tabela">';
                echo '<h3><i class="fas fa-table"></i> 3. Verificando tabela "contatos"...</h3>';
                
                $result = $conexao->query("SHOW TABLES LIKE 'contatos'");
                if ($result->num_rows > 0) {
                    echo '<div class="status-box sucesso">';
                    echo '<i class="fas fa-check-circle"></i> ✅ Tabela "contatos" encontrada!';
                    echo '</div>';
                    
                    // Mostrar estrutura da tabela
                    echo '<h4><i class="fas fa-code"></i> Estrutura da tabela:</h4>';
                    
                    $result = $conexao->query("DESCRIBE contatos");
                    echo '<table>';
                    echo '<tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th></tr>';
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td><strong>' . $row['Field'] . '</strong></td>';
                        echo '<td>' . $row['Type'] . '</td>';
                        echo '<td>' . ($row['Null'] == 'YES' ? 'Sim' : 'Não') . '</td>';
                        echo '<td>' . $row['Key'] . '</td>';
                        echo '<td>' . ($row['Default'] ?? 'NULL') . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                    
                    // ============================================
                    // TESTE 4: DADOS ARMAZENADOS
                    // ============================================
                    echo '<div class="card card-dados">';
                    echo '<h3><i class="fas fa-list-alt"></i> 4. Dados armazenados...</h3>';
                    
                    // Estatísticas
                    $total_result = $conexao->query("SELECT COUNT(*) as total FROM contatos");
                    $total = $total_result->fetch_assoc()['total'];
                    
                    $hoje_result = $conexao->query("SELECT COUNT(*) as hoje FROM contatos WHERE DATE(data_envio) = CURDATE()");
                    $hoje = $hoje_result->fetch_assoc()['hoje'];
                    
                    $nao_lidos_result = $conexao->query("SELECT COUNT(*) as nao_lidos FROM contatos WHERE lido = FALSE");
                    $nao_lidos = $nao_lidos_result->fetch_assoc()['nao_lidos'];
                    
                    echo '<div class="grid">';
                    echo '<div class="stat-box">';
                    echo '<div class="stat-label">Total de Contatos</div>';
                    echo '<div class="stat-number">' . $total . '</div>';
                    echo '</div>';
                    
                    echo '<div class="stat-box">';
                    echo '<div class="stat-label">Contatos Hoje</div>';
                    echo '<div class="stat-number">' . $hoje . '</div>';
                    echo '</div>';
                    
                    echo '<div class="stat-box">';
                    echo '<div class="stat-label">Não Lidos</div>';
                    echo '<div class="stat-number">' . $nao_lidos . '</div>';
                    echo '</div>';
                    echo '</div>';
                    
                    // Listar dados
                    $result = $conexao->query("SELECT * FROM contatos ORDER BY data_envio DESC LIMIT 10");
                    
                    if ($result->num_rows > 0) {
                        echo '<h4><i class="fas fa-history"></i> Últimos 10 contatos:</h4>';
                        echo '<table>';
                        echo '<tr><th>ID</th><th>Data</th><th>Nome</th><th>E-mail</th><th>Assunto</th><th>Status</th></tr>';
                        
                        while ($row = $result->fetch_assoc()) {
                            $status = $row['lido'] ? 
                                '<span style="color: #28a745;"><i class="fas fa-check-circle"></i> Lido</span>' : 
                                '<span style="color: #dc3545;"><i class="fas fa-envelope"></i> Novo</span>';
                            
                            echo '<tr>';
                            echo '<td>' . $row['id'] . '</td>';
                            echo '<td>' . date('d/m/Y H:i', strtotime($row['data_envio'])) . '</td>';
                            echo '<td><strong>' . htmlspecialchars($row['nome']) . '</strong></td>';
                            echo '<td>' . htmlspecialchars($row['email']) . '</td>';
                            echo '<td>' . htmlspecialchars($row['assunto']) . '</td>';
                            echo '<td>' . $status . '</td>';
                            echo '</tr>';
                        }
                        
                        echo '</table>';
                        
                        if ($total > 10) {
                            echo '<p class="info status-box">Mostrando 10 de ' . $total . ' registros. <a href="#ver-todos" onclick="verTodos()">Ver todos</a></p>';
                        }
                        
                    } else {
                        echo '<div class="alerta status-box">';
                        echo '<i class="fas fa-inbox"></i> A tabela está vazia. Envie um formulário para testar.';
                        echo '</div>';
                    }
                    
                    echo '</div>'; // Fecha card-dados
                    
                } else {
                    echo '<div class="status-box erro">';
                    echo '<i class="fas fa-times-circle"></i> ❌ Tabela "contatos" não encontrada!';
                    echo '</div>';
                    
                    echo '<div class="code">';
                    echo '<strong>Crie a tabela com este SQL:</strong><br><br>';
                    echo "CREATE TABLE contatos (<br>";
                    echo "    id INT AUTO_INCREMENT PRIMARY KEY,<br>";
                    echo "    nome VARCHAR(100) NOT NULL,<br>";
                    echo "    email VARCHAR(100) NOT NULL,<br>";
                    echo "    telefone VARCHAR(20),<br>";
                    echo "    assunto VARCHAR(50) NOT NULL,<br>";
                    echo "    mensagem TEXT NOT NULL,<br>";
                    echo "    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,<br>";
                    echo "    lido BOOLEAN DEFAULT FALSE<br>";
                    echo ");";
                    echo '</div>';
                }
                
                echo '</div>'; // Fecha card-tabela
                
            } else {
                echo '<div class="status-box erro">';
                echo '<i class="fas fa-times-circle"></i> ❌ Banco de dados "' . $banco . '" não encontrado!';
                echo '</div>';
                
                echo '<div class="code">';
                echo '<strong>Crie o banco de dados com este SQL:</strong><br><br>';
                echo "CREATE DATABASE $banco CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;<br><br>";
                echo "USE $banco;<br><br>";
                echo "-- Em seguida, crie a tabela contatos";
                echo '</div>';
            }
            
            echo '</div>'; // Fecha card-banco
            
            $conexao->close();
        }
        
        echo '</div>'; // Fecha card-conexao
        
        // ============================================
        // TESTE 5: ARQUIVOS DO SISTEMA
        // ============================================
        echo '<div class="card card-arquivos">';
        echo '<h3><i class="fas fa-file-code"></i> 5. Verificando arquivos do sistema...</h3>';
        
        $arquivos = [
            'salvar.php' => 'Script principal para salvar contatos',
            'contato.html' => 'Formulário de contato',
            'teste_conexao.php' => 'Esta página de teste',
            'logs_contatos.txt' => 'Arquivo de logs (gerado automaticamente)'
        ];
        
        echo '<table>';
        echo '<tr><th>Arquivo</th><th>Status</th><th>Descrição</th></tr>';
        
        foreach ($arquivos as $arquivo => $descricao) {
            if (file_exists($arquivo)) {
                $tamanho = filesize($arquivo);
                $status = '<span style="color: #28a745;"><i class="fas fa-check-circle"></i> Encontrado (' . $tamanho . ' bytes)</span>';
            } else {
                $status = '<span style="color: #dc3545;"><i class="fas fa-times-circle"></i> Não encontrado</span>';
            }
            
            echo '<tr>';
            echo '<td><strong>' . $arquivo . '</strong></td>';
            echo '<td>' . $status . '</td>';
            echo '<td>' . $descricao . '</td>';
            echo '</tr>';
        }
        
        echo '</table>';
        echo '</div>'; // Fecha card-arquivos
        ?>
        
        <!-- ============================================
        SEÇÃO DE AÇÕES
        ============================================ -->
        <div class="card card-acoes">
            <h3><i class="fas fa-cogs"></i> 6. Ações disponíveis</h3>
            
            <div class="destaque">
                <h4><i class="fas fa-rocket"></i> Sistema Portfolio BD pronto para uso!</h4>
                <p>O banco de dados <strong>portfolio_bd</strong> está configurado e funcionando.</p>
            </div>
            
            <div style="text-align: center; margin: 25px 0;">
                <a href="contato.html" class="btn">
                    <i class="fas fa-envelope"></i> Testar Formulário
                </a>
                
                <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-verde">
                    <i class="fas fa-database"></i> Abrir phpMyAdmin
                </a>
                
                <a href="index.html" class="btn btn-azul">
                    <i class="fas fa-home"></i> Voltar ao Portfólio
                </a>
                
                <button onclick="location.reload()" class="btn">
                    <i class="fas fa-sync-alt"></i> Atualizar Teste
                </button>
            </div>
        </div>
        
        <!-- ============================================
        INFORMAÇÕES DO SISTEMA
        ============================================ -->
        <div class="code">
            <strong><i class="fas fa-info-circle"></i> Informações do Sistema:</strong><br><br>
            PHP Version: <?php echo phpversion(); ?><br>
            Server Software: <?php echo $_SERVER['SERVER_SOFTWARE']; ?><br>
            Document Root: <?php echo $_SERVER['DOCUMENT_ROOT']; ?><br>
            Current Directory: <?php echo __DIR__; ?><br>
            MySQL Extension: <?php echo extension_loaded('mysqli') ? '✅ Carregada' : '❌ Não carregada'; ?><br>
            Time: <?php echo date('d/m/Y H:i:s'); ?>
        </div>
    </div>
    
    <script>
        function verTodos() {
            alert('Para ver todos os registros, acesse o phpMyAdmin ou crie um painel admin.');
        }
    </script>
</body>
</html>