<?php
// Configurações do banco de dados
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'portfolio_db';

echo "<h2>Teste de Conexão com Banco de Dados</h2>";
echo "<p>Tentando conectar com:</p>";
echo "<ul>";
echo "<li>Host: $host</li>";
echo "<li>Usuário: $usuario</li>";
echo "<li>Banco: $banco</li>";
echo "</ul>";

// Testar conexão
$conexao = @new mysqli($host, $usuario, $senha);

if ($conexao->connect_error) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 20px; border-radius: 10px;'>";
    echo "<h3>❌ Erro de Conexão:</h3>";
    echo "<p>" . $conexao->connect_error . "</p>";
    echo "<p><strong>Soluções possíveis:</strong></p>";
    echo "<ol>";
    echo "<li>Verifique se o MySQL está rodando</li>";
    echo "<li>Verifique o usuário e senha do MySQL</li>";
    echo "<li>Verifique se o XAMPP/WAMP está ativo</li>";
    echo "</ol>";
    echo "</div>";
} else {
    echo "<div style='background: #d4edda; color: #155724; padding: 20px; border-radius: 10px;'>";
    echo "<h3>✅ Conexão bem-sucedida!</h3>";
    echo "<p>Conexão estabelecida com o MySQL.</p>";
    
    // Testar se o banco existe
    if ($conexao->select_db($banco)) {
        echo "<p>✅ Banco de dados '$banco' encontrado.</p>";
        
        // Testar se a tabela existe
        $result = $conexao->query("SHOW TABLES LIKE 'contatos'");
        if ($result->num_rows > 0) {
            echo "<p>✅ Tabela 'contatos' encontrada.</p>";
            
            // Mostrar estrutura da tabela
            echo "<h4>Estrutura da tabela 'contatos':</h4>";
            $result = $conexao->query("DESCRIBE contatos");
            echo "<table border='1' cellpadding='10'>";
            echo "<tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['Field'] . "</td>";
                echo "<td>" . $row['Type'] . "</td>";
                echo "<td>" . $row['Null'] . "</td>";
                echo "<td>" . $row['Key'] . "</td>";
                echo "<td>" . $row['Default'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>❌ Tabela 'contatos' NÃO encontrada.</p>";
        }
    } else {
        echo "<p>❌ Banco de dados '$banco' NÃO encontrado.</p>";
    }
    
    echo "</div>";
}

$conexao->close();
?>